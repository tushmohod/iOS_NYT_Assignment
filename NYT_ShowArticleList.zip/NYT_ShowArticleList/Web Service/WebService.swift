//
//  Services.swift
//  NYT_ShowArticleList
//
//  Created by Tushar Mohod on 02/07/19.
//  Copyright © 2019 Tushar Mohod. All rights reserved.
//

import Foundation
import SystemConfiguration
import UIKit

class WebService {
    
    /*! @brief A property to store API key */
    static var userSearchkey : String = "C7xhB5Zi0mhEO5S1kKgNNvzePv9L9djY"
    /*! @brief An object of view controller to show alerts to user */
    static var showActions = ShowActionViews()
    
    /*!
     @brief  Its a method to make server call and get data for articles
     
     @param  <i>searchTerm</i> search keyword entered by user, <i>success</i> closure to pass data if sucess, <i>failure</i> closure to pass data if failure,<i>isSearchPoupularArticle</i> is <i>Bool</i> as to differentiate popular and normal search article.
     
     @discussion This method is to make server call to a spesific <i>URL</i>
     
     @return null
     
     @remark It handles complete web service request and response 
     */
    class func fnGetSearchResults(searchTerm: String, success: @escaping (Dictionary<String,Any>)-> Void, failure: @escaping (String)->Void,isSearchPoupularArticle : Bool = false) {
        CustomLoader.fnTurnOnSpinner(message: "Loading..")
        var url = ""
        if isSearchPoupularArticle {
            url = "\(SEARCH_POPULAR_ARTICLE_URL)\(searchTerm)/1.json?&api-key=\(userSearchkey)"
        }else {
            url = "\(SEARCH_ARTICLE_URL)\(searchTerm)&api-key=\(userSearchkey)"
        }
        url = url.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!
        let request = URLRequest(url: URL(string:url)!)
        let session = URLSession(configuration: .default)
        
        let dataTask = session.dataTask(with: request) { (data, response, error) in
            if error != nil {
                print("\(error.debugDescription) DataTask error: \(error!.localizedDescription)")
               // CustomLoader.fnTurnOffSpinner()
            } else {
                DispatchQueue.main.async {
                    do {
                        let jsonObject = try JSONSerialization.jsonObject(with: data!, options: []) as! Dictionary<String,Any>
                      //  CustomLoader.fnTurnOffSpinner()
                        success(jsonObject)
                        
                    }catch {
                        //CustomLoader.fnTurnOffSpinner()
                        failure("error")
                    }
                    CustomLoader.fnTurnOffSpinner()
                }
            }
           
        }
        dataTask.resume()
    }
}
