//
//  Article.swift
//  NYT_ShowArticleList
//
//  Created by Tushar Mohod on 02/07/19.
//  Copyright © 2019 Tushar Mohod. All rights reserved.
//

import Foundation

class Article : NSObject {
    
    /*! @brief A property to store article name */
    var articleName : String?
    /*! @brief A property to store article publishing date */
    var articlePubDate : String?
    
    /*!
     @brief  Its a constructor to initialize values for search articles
     
     @param  <i>Dictionary</i> data in key-value pair to assign it to a object
     
     @discussion This method is to perform date formatting on values and assign values to Article object
     
     @return null
     
     @remark Initialise search articles
     */
    init(dictionary : Dictionary<String,Any>) {
        
        guard var articlePublishingDate = dictionary["pub_date"] as? String else {
            return;
        }
        
        let dateFormatterGet = DateFormatter()
        dateFormatterGet.dateFormat = "yyyy-MM-dd'T'HH:mm:ssZZZZZ"
        
        let dateFormatterSave = DateFormatter()
        dateFormatterSave.dateFormat = "yyyy-MM-dd"
        
        if let date = dateFormatterGet.date(from: articlePublishingDate) {
            print(dateFormatterSave.string(from: date))
            articlePublishingDate = dateFormatterSave.string(from: date)
        } else {
            print("There was an error decoding the string")
        }
        
        self.articlePubDate = articlePublishingDate
        
        if let dicHeadline = dictionary["headline"] as? Dictionary<String,Any> {
            guard let articleName = dicHeadline["main"] else {
                return
            }
            self.articleName = articleName as? String ?? ""
        }
        
    }
    
    /*!
     @brief  Its a constructor to initialize values for popular search articles
     
     @param  <i>Dictionary</i> data in key-value pair to assign it to a object, <i>isPopularArticle</i> to get differentiate an operation for popular search
     
     @discussion This method is to assign values to popular article object
     
     @return null
     
     @remark Initialise popular search articles
     */
    init(dictionary : Dictionary<String,Any>,isPopularArticle : Bool) {
        /*
        self.articlePubDate = dictionary["published_date"] as? String
        self.articleName = dictionary["title"] as? String
        */
        
        guard let articlePublishingDate = dictionary["published_date"] else {
            return
        }
        self.articlePubDate = articlePublishingDate as? String ?? ""
        
        guard let articleName = dictionary["title"] else {
            return
        }
        self.articleName = articleName as? String ?? ""
        
    }
}
