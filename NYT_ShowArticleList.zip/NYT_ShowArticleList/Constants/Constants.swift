//
//  Constants.swift
//  NYT_ShowArticleList
//
//  Created by Tushar Mohod on 02/07/19.
//  Copyright © 2019 Tushar Mohod. All rights reserved.
//

import Foundation

/// Font
let HELVETICA_REGULAR   = "Helvetica"
let HELVETICA_BOLD      = "Helvetica-Bold"


/// web service
let SEARCH_ARTICLE_URL          = "https://api.nytimes.com/svc/search/v2/articlesearch.json?q="
let SEARCH_POPULAR_ARTICLE_URL  = "https://api.nytimes.com/svc/mostpopular/v2/"


/// Show Messages to User
let SEARCH_STRING_FORMAT_ERROR  = "Enter a valid string"
let INTERNET_CONNECTION_ERROR   = "Please Connect to Internet"
let NO_DATA_FOUND               = "No Data Found"

/// Page Titles
let DASHBORAD_PAGE_TITLE       = "NYT"
let SEARCH_PAGE_TITLE          = "Search"
let ARTICLE_LIST_PAGE_TITLE    = "Articles"
