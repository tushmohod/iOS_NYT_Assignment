//
//  ArticlesListViewController.swift
//  NYT_ShowArticleList
//
//  Created by Tushar Mohod on 02/07/19.
//  Copyright © 2019 Tushar Mohod. All rights reserved.
//

import Foundation
import UIKit

class ArticlesListViewController : UITableViewController {
    /*! @brief An array which holds objects of Any type */
    var arrArticles : [Any]   = []
    /*! @brief Height of table view row */
    var cellHeight  : CGFloat = 70
    
    /*! @brief It is life cycle method of UIViewController to initialise data */
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.tableView.tableFooterView = UIView()
        self.tableView.reloadData()
        self.navigationItem.title = ARTICLE_LIST_PAGE_TITLE
    }
    
    /*! @brief It takes number of rows in each section  */
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arrArticles.count
    }
    
    /*! @brief It displays and resuse each row to show data on table view   */
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = UITableViewCell(style: .subtitle, reuseIdentifier: "articleSearchCell")
        cell.textLabel?.numberOfLines = 0;
        cell.textLabel?.sizeToFit()
        let item = self.arrArticles[indexPath.row] as! Article
        cell.textLabel?.text = item.articleName!
        cell.detailTextLabel?.text = item.articlePubDate!
        cell.selectionStyle = .none

        return cell
    }
    
    /*! @brief It assignes a height for each table cell */
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return cellHeight
    }
    
}
