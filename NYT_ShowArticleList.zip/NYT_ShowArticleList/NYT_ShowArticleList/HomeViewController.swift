//
//  ViewController.swift
//  NYT_ShowArticleList
//
//  Created by Tushar Mohod on 01/07/19.
//  Copyright © 2019 Tushar Mohod. All rights reserved.se
//

import UIKit


class HomeViewController: UITableViewController {
    
    /*! @brief An array which holds type of Article objects */
    var arrPopularArticles : [Article] = []
    /*! @brief An object of view controller to show alerts to user */
    var showActions = ShowActionViews()
    
     /*! @brief It is life cycle method of UIViewController to initialise data */
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        self.tableView.tableFooterView = UIView()
        self.navigationItem.title = DASHBORAD_PAGE_TITLE
    }
    
    /*! @brief It takes number of rows in each section  */
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0 {
            return 1
        }
        else {
            return 3
        }
    }
    
    /*! @brief It provides number of section to table view  */
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    
    /*! @brief It displays and resuse each row to show data on table view   */
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = UITableViewCell(style: .default, reuseIdentifier: "articleCell")
        cell.accessoryType  = .disclosureIndicator
        cell.selectionStyle = .none
        
        if indexPath.section == 0 {
            cell.textLabel?.text = "Search Articles"
        }
        else {
            switch indexPath.row {
            case 0:
                cell.textLabel?.text = "Most Viewed"
            case 1 :
                cell.textLabel?.text = "Most Shared"
            case 2 :
                cell.textLabel?.text = "Most Emailed"
            default : break
            }
        }
        
        return cell;
    }
    
    /*! @brief It shows header on tableview  */
    override func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView = UIView(frame: CGRect(x: 0, y: 0, width: self.view.frame.width, height: 50))
        let lblTitle = UILabel()
        lblTitle.text = section == 0 ? "Search" : "Popular"
        lblTitle.font = UIFont(name: HELVETICA_BOLD, size: 15.0)
        lblTitle.frame = CGRect(x: 15, y: 30, width: self.view.frame.width, height: 20)
        headerView.addSubview(lblTitle)
        return headerView
    }
    
    /*! @brief It provides height to header of table view */
    override func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 50
    }
    
    /*! @brief It recives user selected row on table and show page accordingly */
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let viewController : UIViewController
        if indexPath.section == 0 {
            viewController = (self.storyboard?.instantiateViewController(withIdentifier:"SearchViewController"))!
            self.navigationController?.pushViewController(viewController, animated: true)
        }
        else {
           showPopularArticles(selectedOption: indexPath.row)
        }        
    }

    /*!
     @brief It takes user selected option to show popular articles
     
     @param  selectedOption The selected user option
     
     @return null
     
     @code
        fnGetPopularArticle(selectedOption)
     @endcode
     */
    func showPopularArticles(selectedOption : Int) -> Void {
        
        switch selectedOption {
        case 0:
            fnGetPopularArticle("viewed")
        case 1 :
            fnGetPopularArticle("shared")
        case 2 :
            fnGetPopularArticle("emailed")
        default:
            break;
        }
    }
    
    /*!
     @brief  It gets popular artical data from server
     
     @param  articleType The selected user artical type
     
     @discussion This method call a function <i>@c WebService.fnGetSearchResults()</i> to get data from server in closure of sucess and failure.
                 In sucess closure we parse data and keep it in <i>arrPopularArticles</i>.
                 It perform sort operation on array to display latest article on top.
     
     @return null
     */
    func fnGetPopularArticle(_ articleType : String) -> Void {
        WebService.fnGetSearchResults(searchTerm: articleType, success:{(jsonResponse)-> Void in
            let arrDocs = jsonResponse["results"] as! [Any]
            if arrDocs.count == 0 {
                let label = self.showActions.showMessage(message: NO_DATA_FOUND, font: UIFont(name: HELVETICA_BOLD, size: 15.0)!)
                self.view.addSubview(label)
                return
            }
            for item in arrDocs {
                let article = Article(dictionary: item as! Dictionary<String,Any>,isPopularArticle : true)
                print("\(article.articleName!)   Date: \(article.articlePubDate!)")
                self.arrPopularArticles.append(article)
            }
            let sortedArray = self.arrPopularArticles.sorted(by: {
                $0.articlePubDate!.compare($1.articlePubDate!) == .orderedDescending
            })
            let viewController = self.storyboard?.instantiateViewController(withIdentifier:"ArticlesListViewController") as! ArticlesListViewController
            viewController.arrArticles = sortedArray
            self.navigationController?.pushViewController(viewController, animated: true)
            
        }, failure: {(errorMessage)->Void in
            print(errorMessage)
        },isSearchPoupularArticle: true)
    }
}

