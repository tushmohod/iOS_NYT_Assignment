//
//  SearchViewController.swift
//  NYT_ShowArticleList
//
//  Created by Tushar Mohod on 02/07/19.
//  Copyright © 2019 Tushar Mohod. All rights reserved.
//

import Foundation
import UIKit

class SearchViewController : UIViewController,UITextFieldDelegate {
    /*! @brief An array which holds type of Article objects */
    var arrArticles : [Article] = []
    
    /*! @brief A textfield to get user search keyword */
    @IBOutlet weak var txtSearchBar: UITextField! {
        didSet {
            txtSearchBar.delegate = self
        }
    }
    /*! @brief An object of view controller to show alerts to user */
    var showActions = ShowActionViews()
     /*! @brief It is life cycle method of UIViewController to initialise data */
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.navigationItem.title = SEARCH_PAGE_TITLE
    }
    
    /*!
     @brief  It performs operation based on user search
     
     @param  <i>sender</i>
     
     @discussion This method is responsible for validating user search keyword, Check network connectivity and call method <i>@c WebService.fnGetSearchResults()</i> to make server call.
     
     @return null
     */
    @IBAction func onSearchButtonClick(_ sender: Any) {
        
        /*! @brief Check for valid string */
        if !validateUserResponse() {
            let lblMessage = showActions.showMessage(message:SEARCH_STRING_FORMAT_ERROR, font: UIFont(name: HELVETICA_BOLD, size: 15.0)!)
            self.view.addSubview(lblMessage);
            return
        }
        
        /*! @brief Check for internet connectivity */
        if Reachability.checkReachablility() == false {
            
            let lblMessage = showActions.showMessage(message:INTERNET_CONNECTION_ERROR, font: UIFont(name: HELVETICA_BOLD, size: 15.0)!)
            self.view.addSubview(lblMessage);
            return
        }

        WebService.fnGetSearchResults(searchTerm: txtSearchBar.text!, success:{(josnArray)-> Void in
            
            let jsonResponse = josnArray["response"] as? Dictionary<String,Any>
            let arrDocs = jsonResponse!["docs"] as! [Any]
            if arrDocs.count == 0 {
                let lblMessage = self.showActions.showMessage(message: NO_DATA_FOUND, font: UIFont(name: HELVETICA_BOLD, size: 15.0)!)
                self.view.addSubview(lblMessage);
                return
            }
            for item in arrDocs {
                let article = Article(dictionary: item as! Dictionary<String,Any>)
                print("\(article.articleName!)   Date: \(article.articlePubDate!)")
                self.arrArticles.append(article)
            }
            
            /// -- Sort Array
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "yyyy-mm-dd"
            let sortedArray = self.arrArticles.sorted(by: {
                $0.articlePubDate!.compare($1.articlePubDate!) == .orderedDescending
            })
            
            self.txtSearchBar.text = ""
            let viewController = self.storyboard?.instantiateViewController(withIdentifier:"ArticlesListViewController") as! ArticlesListViewController
            viewController.arrArticles = sortedArray
            self.navigationController?.pushViewController(viewController, animated: true)
            
        }, failure: {(errorMessage)->Void in
            
            print(errorMessage)
        })
    }
    
     /*! @brief Validate the user entered search */
    func validateUserResponse() -> Bool {
     
        txtSearchBar.text = txtSearchBar.text?.trimmingCharacters(in: .whitespaces)
        if txtSearchBar.text == "" || txtSearchBar.text?.count == 0 {
            return false
        }
        return true
    }
    
    /*! @brief UITextField delegate method */
    func textFieldDidBeginEditing(_ textField: UITextField) {
        textField.returnKeyType = .search
    }
    
    /*! @brief UITextField delegate method */
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        onSearchButtonClick(textField.text!)
        textField.resignFirstResponder();
        return true;
    }
}
