//
//  CustomLoader.swift
//  NYT_ShowArticleList
//
//  Created by Tushar Mohod on 03/07/19.
//  Copyright © 2019 Tushar Mohod. All rights reserved.
//
import Foundation
import UIKit
class CustomLoader
{
    /*! @brief Its an alert to show as a loading/activity indicator */
    private static var alert : UIAlertController? = nil
    
    /*!
     @brief  It gets <i>UIAlertController</i> to show activity indicator
     
     @param  A message to display when its visible
     
     @discussion It creates alert view with activity indicator as a subview
     
     @return <i>UIAlertController</i>
     
     @remark Its a class method
     */
    private class func fnGetAlertLoader(message : String) -> UIAlertController {
        alert = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        let loadingIndicator = UIActivityIndicatorView(frame: CGRect(x: 10, y: 5, width: 50, height: 50))
        loadingIndicator.hidesWhenStopped = true
        loadingIndicator.style = UIActivityIndicatorView.Style.gray
        loadingIndicator.startAnimating()
        alert!.view.addSubview(loadingIndicator)
        return alert!
    }
    
    /*!
     @brief  It turns activity indicator visible and starts spinning
     
     @param  A message to display when its visible
     
     @discussion present on top of screen as a alert view
     
     @return null
     
     @remark Its a class method
     */
    internal class func fnTurnOnSpinner(message : String) {
        let alert = CustomLoader.fnGetAlertLoader(message: message)
        let vc = (UIApplication.shared.delegate as! AppDelegate).window?.rootViewController
        vc?.present(alert, animated: false, completion: nil)
    }
    
    /*!
     @brief  It turns activity indicator hidden and stops spinning
     
     @param  A message to display when its visible
     
     @discussion present on top of screen as a alert view
     
     @return null
     
     @remark Its a class method
     */
    internal class func fnTurnOffSpinner() {
        
        let vc = (UIApplication.shared.delegate as! AppDelegate).window?.rootViewController
        vc?.dismiss(animated: true, completion: nil)
    }
    
    /*!
     @brief  It turns activity indicator hidden and stops spinning
     
     @param  A message to display when its visible
     
     @discussion It provides completion handler after stops spinning
     
     @return null
     
     @remark Its a class method
     */
    internal class func fnTurnOffSpinnerWithCompletion(completed : @escaping () -> Void) {
        let vc = (UIApplication.shared.delegate as! AppDelegate).window?.rootViewController
        vc?.dismiss(animated: true, completion: {() -> Void in completed()})
    }
}
