//
//  ActivityIndicator.swift
//  NYT_ShowArticleList
//
//  Created by Tushar Mohod on 03/07/19.
//  Copyright © 2019 Tushar Mohod. All rights reserved.
//

import Foundation
import UIKit

class ShowActionViews : UIViewController {

    /*! @brief Its a margin of message label */
    var MARGIN : CGFloat = 30.0
    /*! @brief Its a height of message label */
    var HEIGHT : CGFloat = 35.0
    
    /*!
     @brief  It shows message to user based on context
     
     @param  articleType The selected user artical type
     
     @discussion It appears on screen with animation so get hidden after assigned timer
     
     @return <i>UIlabel</i>  which appears on screen
     
     @remark It can be used thoughout an application
     */
    func showMessage(message : String, font: UIFont) -> UILabel {
        let messageLabel = UILabel()
        messageLabel.backgroundColor = UIColor.black.withAlphaComponent(0.6)
        messageLabel.textColor = UIColor.white
        messageLabel.font = font
        messageLabel.textAlignment = .center;
        messageLabel.text = message
        let expectedLabelSize: CGSize = messageLabel.sizeThatFits(CGSize(width:320, height: 35))
        messageLabel.frame = CGRect(x: self.view.frame.size.width/2 - (expectedLabelSize.width + MARGIN)/2, y: self.view.frame.size.height/2 - (HEIGHT * 2) , width: expectedLabelSize.width + MARGIN, height: HEIGHT)
        messageLabel.alpha = 1.0
        messageLabel.layer.cornerRadius = 10;
        messageLabel.clipsToBounds  =  true
        UIView.animate(withDuration: 4.0, delay: 0.1, options: .curveEaseOut, animations: {
            messageLabel.alpha = 0.0
        }, completion: {(isCompleted) in
            messageLabel.removeFromSuperview()
        })
        
        return messageLabel
    }
}
